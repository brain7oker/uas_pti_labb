export const countries = [
      {
            key: 1,
            text: "Argentina",
            value: "ar"
      },
      {
            key: 2,
            text: "Australia",
            value: "au"
      },
      {
            key: 3,
            text: "Brazil",
            value: "br"
      },
      {
            key: 4,
            text: "Canada",
            value: "ca"
      },
      {
            key: 5,
            text: "China",
            value: "ch"
      },
      {
            key: 6,
            text: "France",
            value: "fr"
      },
      {
            key: 7,
            text: "Germany",
            value: "de"
      },
      {
            key: 8,
            text: "Hong Kong",
            value: "hk"
      },
      {
            key: 9,
            text: "India",
            value: "in"
      },
      {
            key: 10,
            text: "Indonesia",
            value: "id"
      },
      {
            key: 12,
            text: "Italy",
            value: "it"
      },
      {
            key: 13,
            text: "Netherlands",
            value: "nl"
      },
      {
            key: 14,
            text: "Norway",
            value: "no"
      },
      {
            key: 15,
            text: "Philippines",
            value: "ph"
      },
      {
            key: 16,
            text: "Russia",
            value: "ru"
      },
      {
            key: 17,
            text: "Saudi Arabia",
            value: "sa"
      },
      {
            key: 18,
            text: "South Africa",
            value: "za"
      },
      {
            key: 20,
            text: "Sweden",
            value: "se"
      },
      {
            key: 21,
            text: "United Kingdom",
            value: "gb"
      },
      {
            key: 22,
            text: "United States",
            value: "us"
      },
]