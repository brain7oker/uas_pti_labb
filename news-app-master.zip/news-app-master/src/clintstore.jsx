import React from "react";


const VITE_GAUTH_ID = "692593559541-2rgin6kcfke1et55od12epm3tth3dp7a.apps.googleusercontent.com"

export default VITE_GAUTH_ID
