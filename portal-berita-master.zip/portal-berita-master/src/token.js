const token = {
    newsapp: 'de3912b84a9e46198909cc76259aa1bb'

}
export default token;